package com.Rashed.startup;


import android.app.Service;
import android.content.Context;

import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;


public class pop extends Service {
	
	private View mView;
	
	private WindowManager.LayoutParams mParams;
	private WindowManager mWindowManager;
	
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		
		mView=new MyLoadView(this);
		
		mParams=new WindowManager.LayoutParams(
				WindowManager.LayoutParams.MATCH_PARENT, 150, 10, 10,
	            WindowManager.LayoutParams.TYPE_SYSTEM_OVERLAY,
	            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
	            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
	            PixelFormat.TRANSLUCENT);
		
		mParams.gravity = Gravity.CENTER;
	    mParams.setTitle("Window test");

	    mWindowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
	    mWindowManager.addView(mView, mParams);
	}
	

	@Override
	public IBinder onBind(Intent arg0) {
		// TODO Auto-generated method stub
		return null;
	}
	
	@Override
	public void onDestroy() {
	    super.onDestroy();
	    ((WindowManager)getSystemService(WINDOW_SERVICE)).removeView(mView);
	    mView = null;
	}

	public class MyLoadView extends View {

	    private Paint mPaint;

	    public MyLoadView(Context context) {
	        super(context);
	        mPaint = new Paint();
	        mPaint.setTextSize(50);
	        mPaint.setARGB(200, 200, 200, 200);
	    }

	    @Override
	    protected void onDraw(Canvas canvas) {
	        super.onDraw(canvas);
	        canvas.drawText("test test test", 10, 150, mPaint);
	       
	        
	    }

	   
	    @Override
	    protected void onDetachedFromWindow() {
	        super.onDetachedFromWindow();
	    }

	    @Override
	    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
	        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
	    }
	}
	
	
}