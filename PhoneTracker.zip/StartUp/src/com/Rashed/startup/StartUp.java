package com.Rashed.startup;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.Menu;

public class StartUp extends Activity {

	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		
		
		showPopUpPhone();
	}

	private void showPopUpPhone() {
		// TODO Auto-generated method stub
		
		AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
  		 
		// set title
		alertDialogBuilder.setTitle("Enter");

		// set dialog message
		alertDialogBuilder
			.setMessage("MD. Rashedul")
			.setCancelable(false)
		
			.setNegativeButton("Close",new DialogInterface.OnClickListener() {
				public void onClick(DialogInterface dialog,int id) {
					// if this button is clicked, just close
					// the dialog box and do nothing
					dialog.cancel();
				}
			});

			// create alert dialog
			AlertDialog alertDialog = alertDialogBuilder.create();

			// show it

			alertDialog.show();
			
			
			
      
		}

	
}
