package com.Rashed.startup;

import java.util.Set;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.widget.ImageView;
import android.widget.Toast;

public class pop2 extends Service {
	
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
        // We want this service to continue running until it is explicitly
        // stopped, so return sticky.
        show();
        
        return START_STICKY;
     
    }

	
	
	
	
	
	

	private void show() {
		// TODO Auto-generated method stub
		ImageView i;
		
		
		
	}








	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return null;
	}

}
